import {Auth} from "./auth";

export function Authenticate(user) {
    return Auth(user);
}